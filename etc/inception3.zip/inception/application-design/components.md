# Application Design — Components

## 시스템 개요

```
┌──────────────────┐         ┌──────────────────┐         ┌──────────────────┐
│  Android 수집앱   │──HTTP──▶│    서버 API       │◀──HTTP──│  웹 대시보드 (SPA)│
│  (스마트폰)       │         │                  │         │  (PC 브라우저)    │
└──────────────────┘         └──────────────────┘         └──────────────────┘
```

## 파트 1: Android 수집앱

| 컴포넌트 | 역할 |
|---|---|
| UsageCollector | UsageStatsManager queryEvents()로 Foreground/Background 이벤트 수집 |
| SessionBuilder | 이벤트를 AppSession(패키지명, 시작, 종료, 사용시간)으로 재구성 |
| LocalStore | Room DB에 AppSession 임시 저장 |
| SyncWorker | WorkManager로 주기적으로 서버에 AppSession 전송 |
| PermissionManager | UsageStats 권한 요청 및 상태 관리 |

**데이터 흐름:**
`UsageStatsManager → UsageCollector → SessionBuilder → LocalStore → SyncWorker → 서버 API`

## 파트 2: 서버 API

| 컴포넌트 | 역할 |
|---|---|
| AuthController | 기기 등록 및 토큰 인증 |
| SessionIngestionController | AppSession 데이터 수신 및 저장 |
| ContextAnalysisService | 활동과 세션 시간 중첩 분석 → Context 생성 |
| ConflictService | 활동 충돌 감지 → 사용자 질문 생성 |
| ClassificationService | Context 기반 최종 분류 (생산/의도적여가/낭비/중립) 판정 |
| BaselineService | 첫 1주 평균 산출, Baseline 고정 비교 |
| WasteCalculationService | 낭비시간 계산, 확보시간 산출 |
| GoalService | 목표 활동 CRUD, 타이머 기록, 수동 기록 |
| RecoveryService | 되찾은 시간 계산, 시간 회수율 산출 |
| ReportService | 일별/주별 리포트 데이터 조회 |
| Database | 모든 데이터 영구 저장 |

**데이터 흐름:**
```
Android 앱 → SessionIngestion → DB
사용자 활동 기록 → DB
                    ↓
ContextAnalysis (세션 + 활동 중첩 분석)
                    ↓
ConflictService (충돌 감지 → 사용자 질문)
                    ↓
ClassificationService (최종 분류 판정)
                    ↓
WasteCalculation (낭비시간 → Baseline 비교 → 확보시간)
                    ↓
RecoveryService (목표 활동 투자 → 되찾은 시간 → 회수율)
                    ↓
ReportService → 웹 대시보드
```

## 파트 3: 웹 대시보드 (SPA) — 6개 화면

| 화면 | 역할 |
|---|---|
| ① 홈 | 오늘 낭비시간, 확보한 시간, 되찾은 시간, 시간 회수율, 목표 진행도 |
| ② Timeline | 시간대별 AppSession + 활동 + 분류 시각화, 잘못된 분류 수정 |
| ③ 앱 관리 | 설치 앱 목록, 기본 분류(4단계) 설정 |
| ④ 시간 되찾기 | 목표 선택 + 타이머 시작, 활동 직접 기록 |
| ⑤ 목표 | 목표 생성, 목표시간 설정, 누적 투자시간, 진행률 |
| ⑥ 리포트 | 일/주 통계, Baseline 비교, 목표별 사용시간 |

## 주요 데이터 엔티티

| 엔티티 | 설명 |
|---|---|
| Device | 등록된 기기 (기기ID, 토큰) |
| AppInfo | 앱 정보 (패키지명, 앱이름, 기본분류) |
| AppSession | 앱 사용 세션 (패키지명, 시작시각, 종료시각, 사용시간) |
| Activity | 사용자 활동 기록 (활동유형, 시작시각, 종료시각) |
| Context | 세션+활동 결합 판정 (sessionId, activityId, 최종분류, 사용자확인여부) |
| Baseline | 첫 1주 평균 (주간 낭비시간) |
| Goal | 목표 활동 (이름, 목표시간, 누적시간) |
| RecoveredTime | 되찾은 시간 기록 (goalId, 시간, 방법: TIMER/MANUAL, 시작/종료) |
| DailySummary | 일별 요약 (날짜, 카테고리별 시간, 낭비시간, 확보시간, 되찾은 시간, 회수율) |
| Conflict | 활동 충돌 질문 (sessionId, activityId, 질문 유형, 사용자 응답) |

## 빌드 범위 (이 워크스페이스에서 만드는 것)

- **서버 API** — 이 워크스페이스의 `src/` 에 작성
- **웹 대시보드** — 이 워크스페이스의 `src/` 에 작성
- **Android 수집앱** — 별도 Android Studio 프로젝트 (설계 문서 + API 스펙만 제공)
