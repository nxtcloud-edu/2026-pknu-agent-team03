# Unit of Work

## 작업 단위 목록

아래 순서대로 하나씩 완료한 뒤 다음으로 넘어간다.

| # | 단위 이름 | 범위 | 의존 |
|---|---|---|---|
| 1 | server-core | DB 스키마(전체 엔티티), 기기 인증, AppSession 수신 API | 없음 |
| 2 | server-analysis | Context 분석(중첩 판정), 활동 충돌 감지·질문, 분류 판정, 사용자 분류 수정 | server-core |
| 3 | server-goal | 목표 CRUD, 타이머/수동 기록, Baseline 비교, 낭비·확보·되찾은 시간 계산, 시간 회수율, 리포트 API | server-core, server-analysis |
| 4 | web-dashboard | SPA 6화면 (홈/Timeline/앱관리/시간되찾기/목표/리포트) | server-core, server-analysis, server-goal |
| 5 | android-spec | Android 수집앱 설계 문서 + API 연동 스펙 (코드 생성은 별도) | server-core |

## CONSTRUCTION 단계 매핑

| 단위 | 01 기능설계 | 02 비기능요구 | 03 비기능설계 | 04 인프라설계 | 05 코드생성 |
|---|---|---|---|---|---|
| server-core | ✓ | ✓ | ✓ | — | ✓ |
| server-analysis | ✓ | — | — | — | ✓ |
| server-goal | ✓ | — | — | — | ✓ |
| web-dashboard | ✓ | ✓ | ✓ | — | ✓ |
| android-spec | ✓ | — | — | — | — (설계문서만) |

- STEP 02(비기능요구): 기술 스택 최초 결정 단위에서만 — server-core, web-dashboard
- STEP 03(비기능설계): 아키텍처 패턴 정하는 단위에서만 — server-core, web-dashboard
- STEP 04(인프라설계): 모두 건너뜀 (로컬 개발 환경)
- android-spec: STEP 05 안 돎 (이 워크스페이스에서 코드 생성 안 함)

## 완료 후

전 단위 완료 → CONSTRUCTION STEP 06 빌드와 테스트 (한 번)
