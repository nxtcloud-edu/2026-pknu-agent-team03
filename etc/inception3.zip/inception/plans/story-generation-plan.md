# Story Generation Plan

## 목표

`requirements.md`의 FR-1~FR-5를 기반으로 페르소나와 유저 스토리를 작성한다.

## 체크리스트

- [x] 페르소나 정의 (1~2명)
- [x] FR-1 수집 관련 스토리
- [x] FR-2 분류 관련 스토리
- [x] FR-3 Baseline 관련 스토리
- [x] FR-4 목표 활동 추적 관련 스토리
- [x] FR-5 대시보드/리포트 관련 스토리
- [x] Acceptance Criteria 작성

## 질문

사용자 페르소나에 대해 확인합니다.

### PQ1. 주 사용자 유형

이 앱의 주 사용자는 어떤 사람인가요?

A) 대학생 — 공부 시간 확보가 목적  
B) 직장인 — 퇴근 후 자기계발 시간 확보가 목적  
C) 일반 스마트폰 사용자 — 특정 직업 제한 없음  
D) 자기관리에 관심 있는 20~30대  
E) Other (please describe after [Answer]: tag below)

[Answer]: D
