# Unit of Work Plan

## 목표

`components.md`의 3파트 시스템을 개발 단위(Unit of Work)로 나눈다.
순서는 의존성 기반 — 하위 계층부터 올라간다.

## 코드 생성 범위

이 워크스페이스에서 만드는 것:
- 서버 API
- 웹 대시보드

Android 수집앱은 설계 문서·API 스펙만 제공한다.

## 체크리스트

- [x] 단위 식별 및 범위 정의
- [x] 단위 간 의존성 정리
- [x] 실행 순서 결정
- [x] unit-of-work.md 작성

## 질문

없음 — components.md와 execution-plan.md에서 근거가 충분하다.
