# Application Design Plan

## 목표

TimeBack 앱의 구성 요소(컴포넌트)와 데이터 흐름을 정의한다.
`inception/application-design/components.md` 에 결과를 남긴다.

## 체크리스트

- [x] 주요 컴포넌트 식별 및 역할 정의
- [x] 컴포넌트 간 데이터 흐름 정의
- [x] 주요 데이터 엔티티 목록
- [x] 화면(Screen) 구성 목록

## 질문

### DQ1. 화면 구성 범위

MVP 대시보드 화면은 어떤 구조를 원하나요?

A) 단일 탭 — 오늘 요약만 보여주고, 주간 리포트는 별도 화면  
B) 탭 3개 — 오늘 / 주간 / 목표활동  
C) 바텀 네비게이션 4개 — 대시보드 / 앱분류 / 목표 / 설정  
D) 최소 2화면 — 메인(요약) + 설정  
E) Other (please describe after [Answer]: tag below)

[Answer]: E — 웹앱(SPA) 형식. 스마트폰에서 수집하고 PC 브라우저에서 대시보드를 본다.