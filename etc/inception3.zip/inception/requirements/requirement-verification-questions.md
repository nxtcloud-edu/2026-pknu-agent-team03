# Requirement Verification Questions

> `spec.md` 에 없는 것만 묻는다. 답을 받은 뒤 `requirements.md` 를 확정한다.

---

## Q1. 시간 분류 기준의 주체

앱 사용을 "낭비 / 생산 / 여가"로 판정할 때, 분류 기준은 누가 정하나요?

A) 사용자가 앱별로 직접 카테고리를 지정한다  
B) 시스템이 기본 카테고리를 제공하고, 사용자가 수정할 수 있다  
C) AI/규칙 엔진이 자동으로 판정하고, 사용자는 결과만 본다  
D) 시간대·맥락에 따라 같은 앱도 다르게 판정한다 (예: 유튜브 — 아침은 생산, 밤은 여가)  
E) Other (please describe after [Answer]: tag below)

[Answer]: B

---

## Q2. Baseline 산정 방식

"Baseline 대비 확보한 시간"에서 Baseline은 어떻게 정해지나요?

A) 최초 1주일 사용 패턴을 자동 기록해서 고정  
B) 사용자가 직접 "하루 SNS 2시간" 같은 목표를 입력  
C) 매주 이동평균으로 자동 갱신  
D) 요일별(평일/주말)로 별도 Baseline  
E) Other (please describe after [Answer]: tag below)

[Answer]: A

---

## Q3. 목표 활동의 형태

사용자가 "되찾은 시간"을 투자하는 목표 활동은 어떤 형태인가요?

A) 앱 내부 타이머(예: "독서 30분") 를 시작해서 기록  
B) 특정 앱 사용 시간이 곧 목표 활동 (예: Kindle 앱 사용 = 독서)  
C) 수동으로 "방금 운동 1시간 했음" 이라고 기록  
D) A + B 혼합 — 타이머도 되고, 지정 앱 사용도 자동 인정  
E) Other (please describe after [Answer]: tag below)

[Answer]: C

---

## Q4. 데이터 저장 위치

수집한 사용 데이터와 분석 결과는 어디에 저장하나요?

A) 기기 로컬(Room DB 등)에만 저장 — 서버 없음  
B) 로컬 + 클라우드 백업(Firebase 등)  
C) 모든 데이터를 서버에 저장, 멀티 디바이스 동기화  
D) 아직 정하지 않았으며 MVP는 로컬만으로 충분  
E) Other (please describe after [Answer]: tag below)

[Answer]:A

---

## Q5. 알림/개입 방식

사용자가 "낭비" 패턴에 빠졌을 때 앱이 어떻게 개입하나요?

A) 알림(Notification)으로 "지금 30분째 SNS 중" 같은 넛지  
B) 오버레이 팝업으로 강하게 차단  
C) 사후 리포트만 — 실시간 개입 없음  
D) 사용자가 강도를 선택 (넛지 / 차단 / 리포트만)  
E) Other (please describe after [Answer]: tag below)

[Answer]: C

---

## Q6. MVP 범위

첫 버전(MVP)에 꼭 들어가야 할 것과 나중에 해도 되는 것을 구분하고 싶습니다.

A) 수집 + 분류 + 대시보드까지만 MVP, 목표 활동 추적은 다음  
B) 수집 + 분류 + 목표 활동 추적까지 MVP, 소셜/공유 기능은 다음  
C) 전부 한 번에 만든다  
D) 핵심 흐름(수집→분석→되찾기) 전체를 최소로 돌아가게 만든다  
E) Other (please describe after [Answer]: tag below)

[Answer]:B
